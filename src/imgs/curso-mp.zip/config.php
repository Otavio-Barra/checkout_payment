<?php 

 return [
    'accesstoken' => '------------------',
    'url_notification_sdk' => 'https://95d60c603db969.lhr.life/curso/sdk/notification.php',
    'url_notification_api' => 'https://95d60c603db969.lhr.life/curso/api/notification.php'
];